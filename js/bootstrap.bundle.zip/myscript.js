document.getElementById("combtn").addEventlistener("click", function(){

			var cb=	document.getElementById("cbox");

			if(cb.style.display == "none"){
				cb.style.display = "block";
			}else{
				cb.style.display = "none";
			}

		});